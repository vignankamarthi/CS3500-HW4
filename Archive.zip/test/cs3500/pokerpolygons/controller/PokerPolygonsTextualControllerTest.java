package cs3500.pokerpolygons.controller;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Unit tests for the PokerPolygonsTextualController class to make sure certain,
 * smaller parts fo the controller are working as expected.
 */
public class PokerPolygonsTextualControllerTest {

  @Test
  public void playGame() {
  }
}