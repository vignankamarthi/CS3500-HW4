package cs3500.pokerpolygons.view;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class PokerTrianglesTextualViewTest {

  @Before
  public void setUp() throws Exception {
  }

  @Test
  public void testToString() {
  }
}