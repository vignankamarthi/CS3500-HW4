package cs3500.pokerpolygons.model.hw02;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class StandardPlayingCardTest {

  @Before
  public void setUp() throws Exception {
  }

  @Test
  public void getRank() {
  }

  @Test
  public void getSuit() {
  }

  @Test
  public void testToString() {
  }

  @Test
  public void testEquals() {
  }
}