package cs3500.pokerpolygons.model.hw02;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;
public class PokerTrianglesTest {

  @Before
  public void setUp() throws Exception {
  }

  @Test
  public void placeCardInPosition() {
  }

  @Test
  public void discardCard() {
  }

  @Test
  public void startGame() {
  }

  @Test
  public void getWidth() {
  }

  @Test
  public void getHeight() {
  }

  @Test
  public void getNewDeck() {
  }

  @Test
  public void getCardAt() {
  }

  @Test
  public void getHand() {
  }

  @Test
  public void getScore() {
  }

  @Test
  public void getRemainingDeckSize() {
  }

  @Test
  public void isGameOver() {
  }
}