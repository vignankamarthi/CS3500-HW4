Changes from HW2:
* I fixed the last Junit test I wasn't passing by creating another helper method
called generateCombinations, that generates all 5 card combinations of a specific hand
for proper scoring using recursion.
* I changed the inner class in sortHandByRank() to a lambda function which made the method
a lot cleaner.
* I also just cleaned up style, syntax, and dangling comments for my PokerTriangles code.
* I added some tests I was missing from the self evaluation,
ensuring I thoroughly tested everything.