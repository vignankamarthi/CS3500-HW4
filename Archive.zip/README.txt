Changes from HW2:
* I fixed the last Junit test I wasn't passing by creating another helper method
called generateCombinations, that generates all 5 card combinations of a specific hand
for proper scoring using recursion.
* I added some tests I was missing from the self evaluation,
ensuring I thoroughly tested everything.